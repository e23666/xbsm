var cnNameReg=/^[\u4E00-\u9FA5\uf900-\ufa2d]{2,10}$/;
var cnAddReg=/^[\u4E00-\u9FA5\uf900-\ufa2d]{1}[\u4E00-\u9FA5\uf900-\ufa2d\w\.\s-]{5,30}$/;
var telReg=/^[\d\-\.]{8,16}$/;
var emailReg=/^\w+([-+.']\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*$/;