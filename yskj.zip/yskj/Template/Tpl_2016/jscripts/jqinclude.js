if(typeof(jQuery)!='undefined'&&typeof($.dialog)=='undefined'){
    document.write(unescape('%3Cscript%20src%3D%22/js2016/root/plugin/lhgdialognew.min.js%3Fskin%3Dwest%26self%3Dtrue%22%3E%3C/script%3E'));
}
if(typeof(template)=='undefined'){
    document.write(unescape('%3Cscript%20src%3D%22/js2016/root/template.js%22%3E%3C/script%3E'));
}
document.write(unescape('%3Cscript%20src%3D%22/js2016/root/plugin/jquery.datepicker.js%22%20charset%3D%22utf-8%22%3E%3C/script%3E'));